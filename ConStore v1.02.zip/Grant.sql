﻿IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = 'IIS APPPOOL\DefaultAppPool')

CREATE USER [$safeprojectname$] 
  FOR LOGIN [IIS APPPOOL\DefaultServer]
GO
EXEC sp_addrolemember 'db_owner', 'ConStoreAdmin11'
GO