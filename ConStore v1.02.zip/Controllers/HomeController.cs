﻿using System;
using System.Collections;
using System.Data;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using $safeprojectname$.Models;


//Before deploy the service 
//install any device that was metion under the link below//https://docs.microsoft.com/en-us/aspnet/web-forms/overview/deployment/visual-studio-web-deployment/deploying-to-iis//go to control panel -> programs-> programs and feature-> turn windows features on and off
//->click the option .net framwork 4.7 advance or above on -> under this option go to WCF Services
//-> click http activation to deploy the service

   // For database connection, we need to go to the web.config and add connectionstrings tag under 
   // the configuration elements, by providing database name, data server name, providers name, etc.
   //example code below:
    //<connectionStrings>
   // <add name = "DefaultConnection"
   //      connectionString="Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False" providerName="System.Data.SqlClient" />
 //  </connectionStrings>

   // using the ssms to creat logins for iis, using IIS APPPOOL / MyAppName (ps the App name is under IIS Panel's Site folder)
   // then map logins to the user of target database

    //    @Styles.Render("~/Content/css")
   // @Scripts.Render("~/bundles/modernizr")

//Caution: if a controller want to access html value, all the named html element should be included in one form with submit element
//or multiple submit element


namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {

        //for gaming view tasks
        public async Task Supplies_method()
        {
            var dices =await Task.FromResult(new Random());
            var section_number =await Task.FromResult(dices.Next(0, 12));
           
            for (int i = 0; i < 24; i++)
            {
                Session["prodcut_name"+(i+1).ToString()] = Supply.supplyitem[i + section_number];
                Session["product_price"+(i+1).ToString()] = Supply.supplybasicprice[i + section_number] + dices.Next(0, 3);
                Session["product_number"+(i+1).ToString()] = 25 + dices.Next(1, 40);
            }
        }

        public async Task Getcapital(string username)
        {
            //query new capital
            var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection OpenStock = new SqlConnection(connectionstring);
            OpenStock.Open();

            DataTable capitaltable = new DataTable();
            var newcapital = "select Capital from Fianacial where UserName =@StoreMaster";
            SqlCommand newcapitaldata = new SqlCommand(newcapital, OpenStock);
            newcapitaldata.Parameters.AddWithValue("@StoreMaster", username);
            await newcapitaldata.ExecuteNonQueryAsync();
            SqlDataAdapter capitalreader = new SqlDataAdapter(newcapitaldata);
            capitalreader.Fill(capitaltable);
            foreach (DataRow capitalrow in capitaltable.Rows)
            {
                Session["CurrentCapital"] = capitalrow[0];
            }

            OpenStock.Close();
            capitaltable.Clear();
        }

        public async Task Openrecord(string username)
        {
            var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection OpenStock = new SqlConnection(connectionstring);
            OpenStock.Open();

            //collect instock information based on last login
            var stockinformquery = "select GoodsName,GoodsPrice,InStockNumber from Stock where UserName = @userlogin";
            SqlCommand getstockinfo = new SqlCommand(stockinformquery, OpenStock);
            getstockinfo.Parameters.AddWithValue("@userlogin", username);
            await getstockinfo.ExecuteNonQueryAsync();
            SqlDataAdapter stockinfo = new SqlDataAdapter(getstockinfo);
            DataTable instockrecord = new DataTable();
            stockinfo.Fill(instockrecord);

            int rowcount = new int();
            foreach (DataRow stock in instockrecord.Rows)
            {
                rowcount += 1;
                //instock Record

                Session["nameofgoods" + rowcount.ToString()] = stock[0].ToString();

                //Selling Price
                if (stock[1] == DBNull.Value) { Session["priceofgoods" + rowcount.ToString()] = ""; }
                //else
                { Session["priceofgoods" + rowcount.ToString()] = stock[1]; }

                //Instock amount
                if (stock[2] == DBNull.Value) { Session["numberofgoods" + rowcount.ToString()] = ""; }
                else
                { Session["numberofgoods" + rowcount.ToString()] = stock[2]; }
            }

            OpenStock.Close();
            instockrecord.Clear();
        }
        //gaming view controller tasks end here


        //User Regesitration
        public async Task Shelf_Construction(string username)
        {
            var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection userinfoinject = await Task.FromResult(new SqlConnection(connectionstring));
            userinfoinject.Open();

            for (int x = 1; x < 19; x++)
            {
                var regeshopprofile = "insert into Stock (Id,UserName,ShelfNum) select Count(*)+1,@regmanager,@shelfnumber from Stock";
                var haveshopprofile = new SqlCommand(regeshopprofile, userinfoinject);
                haveshopprofile.Parameters.AddWithValue("@regmanager", username);
                haveshopprofile.Parameters.AddWithValue("@shelfnumber", x);
                haveshopprofile.ExecuteNonQuery();
            }
            userinfoinject.Close();
        }

        public async Task Shop_registration(string user, string password, string Repassword)
        {
            var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection userinfoinject = new SqlConnection(connectionstring);
            userinfoinject.Open();

            var userupdatequery = "INSERT INTO userinfo (UserName,password,Repassword) VALUES (@user,@password,@repassword)";
            var updateuserinfo = new SqlCommand(userupdatequery, userinfoinject);
            updateuserinfo.Parameters.AddWithValue("@user", user);
            updateuserinfo.Parameters.AddWithValue("@password", password);
            updateuserinfo.Parameters.AddWithValue("@repassword", Repassword);
            await updateuserinfo.ExecuteNonQueryAsync();

            userinfoinject.Close();
        }

        public async Task Basic_capital(string username)
        {
            var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection userinfoinject = new SqlConnection(connectionstring);
            userinfoinject.Open();

            var givecaptial = "insert into Fianacial (Id,UserName,Capital) select COUNT(*)+1,@yourname,@gaincapital from Fianacial";
            var gaincapital = new SqlCommand(givecaptial, userinfoinject);
            gaincapital.Parameters.AddWithValue("@yourname", username);
            gaincapital.Parameters.AddWithValue("@gaincapital", 5000);
            await gaincapital.ExecuteNonQueryAsync();
        }
        // block end here

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "您好，这是我所做Web App的范例.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "我的电子邮箱式：495068849@qq.com";
            return View();
        }

        public ActionResult Registerary()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> UserInfo(string LOGIN, string PASS,string REPASS)
        {
            Session["User"] = await Task.FromResult(LOGIN);
            Session["Password"] = await Task.FromResult(PASS);
            Session["ReEnterPass"] = await Task.FromResult(REPASS);
            try
            {
              var Reg= Task.Run(async() =>await Shop_registration(
                  Session["User"].ToString(), Session["Password"].ToString(),Session["ReEnterPass"].ToString()));
                Reg.Wait();
                if(Reg.IsCompleted == true)
                {
                    var Financial = Task.Run(async () => await Basic_capital(Session["User"].ToString()));
                    Financial.Wait();
                    if(Financial.IsCompleted == true)
                    {
                        var Shelf = Task.Run(async () => await Shelf_Construction(Session["User"].ToString()));
                        Shelf.Wait();
                        if(Shelf.IsCompleted == true)
                        {
                            Reg.Dispose();
                            Financial.Dispose();
                            Shelf.Dispose();
                        }
                    }
                }
       
            }
            catch
            {
                return RedirectToAction("RegFail");
            }


            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Login(string username, string password)
        {
            var userinfoquery = "select UserName from userinfo where UserName = @userlogin and password = @loginpass";
            var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection LOGINAUTH =await Task.FromResult(new SqlConnection(connectionstring));
            
            var getuserdata = await Task.FromResult(username);
            var getpass = await Task.FromResult(password);
            
            LOGINAUTH.Open();
            SqlCommand getuserinfo =await Task.FromResult(new SqlCommand(userinfoquery, LOGINAUTH));
            await Task.Run(()=> getuserinfo.Parameters.AddWithValue("@userlogin", getuserdata.ToString()));
            await Task.Run(()=> getuserinfo.Parameters.AddWithValue("@loginpass", getpass.ToString())); 

            await getuserinfo.ExecuteNonQueryAsync();
            SqlDataReader whetherlogin =await Task.FromResult(getuserinfo.ExecuteReader());
            if (whetherlogin.HasRows == false)
            {
               ViewBag.Message = "登陆失败";
            }
            else
            {
                Session["NameofUser"] = getuserdata;
                return RedirectToAction("Gaming");
            } 
           
            return View();
        }

        [HttpGet]
        public ActionResult Gaming(
            //submit argument is used by .net mvc api to get this type name
            //and this will be the ref to search every html element whose name attribute matches the ref
            //use switch case block, developer can easily set up different code block for 
            //each element.
            string submit)
        {
            ViewBag.Message ="今日店长   " + Session["NameofUser"].ToString();
            
            var supplies_factory = Task.Run(() => Supplies_method());
            supplies_factory.Wait();
            if (supplies_factory.IsCompleted == true)
            {
                var open = Task.Run(async() => await Openrecord(Session["NameofUser"].ToString()));
                open.Wait();
                if(open.IsCompleted == true)
                {
                    var capital = Task.Run(async() => await Getcapital(Session["NameofUser"].ToString()));
                    capital.Wait();
                    if(capital.IsCompleted == true)
                    {
                        supplies_factory.Dispose();
                        open.Dispose();
                        capital.Dispose();
                    }
                }
            }
            //end

            switch (submit)
            {
                case "Update":
                    
                    break;
            }
           
          
            return View("Gaming","BlankLayerOut");
        }

        public ActionResult RegFail()
        {
            return View();
        }

        public ActionResult dynamicpage()
        {
            return View();
        }

    }
}