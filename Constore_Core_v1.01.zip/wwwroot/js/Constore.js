﻿//use parseint javascript can parse any integer in one var and combine all int together

function passuserinfo() {
    var userform = new FormData();
    userform.append("username", document.getElementById(username).value);
    userform.append("password", document.getElementById(password).value);
    $.ajax({
        type: 'POST',
        url: 'Url.Action("Login")',
        dataType: "json",
        data: userform
    })
}

function onloadpagedata() {
    var products = ["USB线", "包子", "充电宝", "蛋糕", "豆奶", "饭团", "关东煮", "果汁", "红烧牛肉面", "花生米",
        "鸡仔饼", "咖啡", "咖喱鱼丸", "烤香肠", "可乐", "绿茶", "美味棒", "面包", "奶茶", "奶昔",
        "能量饮料", "牛奶", "糯米糍", "啤酒", "巧克力", "薯片", "酸奶", "甜甜圈", "威化饼", "仙贝",
        "香烟", "杏仁", "雪糕", "雨伞", "杂志", "纸巾"] //size 36 items 

    for (i = 1; i < 10; i++) {
        var random_demand = Math.floor(Math.random() * 36);
        document.getElementById("need" + i.toString()).value = products[random_demand];
    }

}

function pressbutton(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.backgroundSize = "95% 95%";
}

function backtodefaultstyle(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.backgroundSize = "100% 100%";

}

function bluegrowingtext(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.textShadow = "1px 1px 2px blue, 0 0 0.3em blue";
}

function bluetext(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.textShadow = "1px 1px 2px blue";
}

function reloadpage() {
    window.location.reload(true);
}

function increasvalues(elementid, titleid) {
    if (document.getElementById(titleid).innerHTML != "" &&
        document.getElementById(elementid).value !="") { 
        var value = parseInt(document.getElementById(elementid).value, 10);
        value = isNaN(value) ? 0 : value;
        value++;
        document.getElementById(elementid).value = value;
    }

    var i;
    var t;
    var record = document.getElementById(titleid);
    if (document.getElementById(elementid).value == "") {
        for (i = 1; i < 19; i++) {
            if (document.getElementById("goodsname" + i.toString()).value == record.innerText) {
                for (t = 1; t < 25; t++) {
                    if (document.getElementById("product" + t.toString()).innerText == record.innerText) {
                        var value2 = parseInt(document.getElementById("productprice" + t.toString()).innerHTML, 10);
                        value2++;
                        document.getElementById(elementid).value = value2;
                        break;
                    }
                    else if (t==24){
                        var value3 = Math.floor(Math.random() * 5) + 3;
                        value3++;
                        document.getElementById(elementid).value = value3;
                    }
                }
            }
        }
    }
}

function decreasvalues(elementid, titleid) {
    if (document.getElementById(titleid).innerHTML == "") { }
    else {
        var value = parseInt(document.getElementById(elementid).value, 10);
        value = isNaN(value) ? 0 : value;
        value--;
        document.getElementById(elementid).value = value;
    }
}

function buttoneffect() {
    document.body.style.fontSize = '20px';
}

function buyin(buyingoods, instock, instocknumber) {
    var i;
    var t;
    var changed = false;
    var record_previouse_goodsname;
    var record_previouse_goodsnum;
    var record_previouse_sellprice;
    var instockcat = document.getElementById(instock);
    var product = document.getElementById(buyingoods);
    var numberofinstock = document.getElementById(instocknumber);

    for (i = 1; i < 18; i++) {
        if (document.getElementById("goodsname" + i.toString()).value == product.innerText) {
            /*
            for (t = 1; t < 25; t++) {
                if (document.getElementById("product" + t.toString()).innerText == product.innerText) {
                        var value = parseInt(document.getElementById("supply" + t.toString()).innerHTML, 10) + parseInt(document.getElementById("num" + i.toString()).value, 10);
                        document.getElementById("supply" + t.toString()).innerHTML = value;
                }
            }*/
            changed = true;
            record_previouse_goodsname = document.getElementById("goodsname" + i.toString()).value;
            record_previouse_goodsnum = document.getElementById("num" + i.toString()).value;
            record_previouse_sellprice = document.getElementById("price" + i.toString()).value;
            document.getElementById("goodsname" + i.toString()).value = "";
            document.getElementById("num" + i.toString()).value = "";
            document.getElementById("Record" + i.toString()).value = "";
            document.getElementById("price" + i.toString()).value = "";
        }
    }
    if (instockcat.value != "") {
        var replacestock = confirm("确定要替换货品？");
        if (replacestock) {
            instockcat.value = product.innerText;
            numberofinstock.value = 0;
        }
        else {
            instock.value = instock.value;
            numberofinstock.value = numberofinstock.value;
        }
    }
    else {
        instockcat.value = product.innerText;
        numberofinstock.value = 0;

        if (changed == true) {
            instockcat.value = record_previouse_goodsname;
            numberofinstock.value = record_previouse_goodsnum;
            for (t = 1; t < 19; t++) {
                if (document.getElementById("Record" + i.toString()).value == instock.value) {
                    document.getElementById("price" + i.toString()).value = record_previouse_sellprice;
                }
            }
        }
    }
}

function stockin(instocknum, instockproduct) {
    var stockproduct = document.getElementById(instockproduct);
    var stocknum = document.getElementById(instocknum);
    var number = parseInt(instocknum.substring(3),10);
    var i;

    for (i = 1; i < 25; i++) {
        var supplyproduct = document.getElementById("product" + i.toString());
        var supplynum = document.getElementById("supply" + i.toString());
        var supplyprice = document.getElementById("productprice" + i.toString());
        if (stockproduct.value == supplyproduct.innerText) {
            var value = parseInt(stocknum.value, 10);
            value++;
            stocknum.value = value;
            supplynum.innerHTML -= 1;

            var dedcutedamount = parseInt(document.getElementById("Capital").value, 10) -
                parseInt(document.getElementById("productprice" + i.toString()).innerHTML, 10)
            dedcutedamount = isNaN(dedcutedamount) ? 0 : dedcutedamount;
            document.getElementById("Capital").value = dedcutedamount;

            var initialvalue = supplyprice.innerHTML;
            var X;
            var Y =0;
            if (stocknum.value == 1) {
                for (X = 1; X < 19; X++) {
                    if (document.getElementById("Record" + X.toString()).innerHTML == ""
                        && document.getElementById("price" + X.toString()).value == "") {
                        document.getElementById("Record" + X.toString()).innerHTML = stockproduct.value;
                        document.getElementById("price" + X.toString()).value = parseInt(initialvalue, 10);
                        Y++;
                        break;
                    }
                    if (Y == 0) {
                        document.getElementById("Record" + number.toString()).innerHTML = stockproduct.value;
                        document.getElementById("price" + number.toString()).value = parseInt(initialvalue, 10);
                    }
                }
            }
            
        }
    }

}

function canclebuy(instocknum, instockproduct) {
    var stockproduct = document.getElementById(instockproduct);
    var stocknum = document.getElementById(instocknum);
    var number = parseInt(instocknum.substring(3), 10);
    var i;
    for (i = 1; i < 25; i++) {
        var supplyproduct = document.getElementById("product" + i.toString());
        var supplynum = document.getElementById("supply" + i.toString());
        if (stockproduct.value == supplyproduct.innerText) {
            var value = parseInt(stocknum.value, 10);
            var value2 = parseInt(supplynum.innerText, 10);
            value--;
            value2++;
            stocknum.value = value;
            supplynum.innerHTML = value2;

            var withdrawtrade = parseInt(document.getElementById("Capital").value, 10) +
                parseInt(document.getElementById("productprice" + i.toString()).innerHTML, 10)
            withdrawtrade = isNaN(withdrawtrade) ? 0 : withdrawtrade;
            document.getElementById("Capital").value = withdrawtrade;

            if (stocknum.value == 0) {
                stocknum.value = "";
                stockproduct.value = "";
                document.getElementById("Record" + number.toString()).innerHTML = "";
                document.getElementById("price" + number.toString()).value = "";
            }
        }
    }
}

function clearupshelf(productid) {
    var q;
    var productname = document.getElementById(productid);

    for (q = 1; q < 19; q++) {
        if (document.getElementById("goodsname" + q.toString()).value == productname.innerText) {
            document.getElementById("goodsname" + q.toString()).value = "";
            document.getElementById("num" + q.toString()).value = "";
        }
    }
}

function getsold(Solditem) {
    var item = document.getElementById(Solditem).value;
    var capital = document.getElementById('Revenue');
    var rand = Math.floor(Math.random() * 5) + 1;

    for (var x = 1; x < 19; x++) {
        if (document.getElementById("goodsname" + x.toString()).value == item) {
            if (confirm("确定要卖出" + item + ",卖出数量" + rand)) {
                if (document.getElementById("num" + x.toString()).value < rand) {
                    document.getElementById("goodsname" + x.toString()).value = "";
                    document.getElementById("num" + x.toString()).value = "";
                    var revenue = parseInt(capital.value, 10) + rand * parseInt(document.getElementById("price" + x.toString()).value, 10)
                    capital.value = parseInt(revenue, 10);
                    break;
                }

                if (document.getElementById("num" + x.toString()).value >= rand) {
                    var revenue = parseInt(capital.value, 10) + rand * parseInt(document.getElementById("price" + x.toString()).value, 10)
                    capital.value = parseInt(revenue, 10);
                    var newstocknum = parseInt(document.getElementById("num" + x.toString()).value, 10) - rand
                    document.getElementById("num" + x.toString()).value = newstocknum;
                    document.getElementById(Solditem).value = "";
                    break;
                }

            }
            else { onloadpagedata(); }
        }
    }

}