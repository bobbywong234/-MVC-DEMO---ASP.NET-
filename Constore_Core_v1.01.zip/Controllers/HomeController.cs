﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Models;
using System.Data;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;


namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
            //for gaming view tasks
            public async Task Supplies_method()
            {
             var dices = await Task.FromResult(new Random());
             var section_number = await Task.FromResult(dices.Next(0, 12));
            
            for(int i = 1; i < 25;i++)
            {
                if(TempData["prodcut_name" + i.ToString()] == null)
                {
                    TempData["prodcut_name" + i.ToString()] = BackEndParameters.supplyitem[section_number+i];
                }
                if (TempData["product_price" + i.ToString()] == null)
                {
                    TempData["product_price" + i.ToString()] = BackEndParameters.supplybasicprice[section_number+i] +dices.Next(3,8);
                }
            }

            var x = await Task.FromResult(new Random());
            for (int t = 1; t<25;t++)
            {
                if (TempData["product_number" + t.ToString()] == null)
                {
                    TempData["product_number" + t.ToString()] = 25 + x.Next(1,40);
                }
            }
           
        }

            public async Task Getcapital(string username)
            {
                //query new capital
                SqlConnection OpenStock = new SqlConnection(SessionKey.connection);
                OpenStock.Open();

                DataTable capitaltable = new DataTable();
                var newcapital = "select Capital from Fianacial where UserName =@StoreMaster";
                SqlCommand newcapitaldata = new SqlCommand(newcapital, OpenStock);
                newcapitaldata.Parameters.AddWithValue("@StoreMaster", username);
                await newcapitaldata.ExecuteNonQueryAsync();
                SqlDataAdapter capitalreader = new SqlDataAdapter(newcapitaldata);
                capitalreader.Fill(capitaltable);
                foreach (DataRow capitalrow in capitaltable.Rows)
                {
                  TempData["CurrentCapital"] = capitalrow[0];
                }

                OpenStock.Close();
                capitaltable.Clear();
            }

            public async Task Openrecord(string username)
            {
                SqlConnection OpenStock = new SqlConnection(SessionKey.connection);
                OpenStock.Open();

                //collect instock information based on last login
                var stockinformquery = "select GoodsName,GoodsPrice,InStockNumber from Stock where UserName = @userlogin";
                SqlCommand getstockinfo = new SqlCommand(stockinformquery, OpenStock);
                getstockinfo.Parameters.AddWithValue("@userlogin", username);
                await getstockinfo.ExecuteNonQueryAsync();
                SqlDataAdapter stockinfo = new SqlDataAdapter(getstockinfo);
                DataTable instockrecord = new DataTable();
                stockinfo.Fill(instockrecord);

                var rowcount = await Task.FromResult(new int());
                foreach (DataRow stock in instockrecord.Rows)
                {
                 rowcount += 1;
                 //instock Record

                 TempData["nameofgoods" + rowcount.ToString()] = stock[0].ToString();

                 //Selling Price
                 if (stock[1] == DBNull.Value) { TempData["priceofgoods" + rowcount.ToString()] = ""; }
                 else
                 { TempData["priceofgoods" + rowcount.ToString()] = stock[1]; }

                 //Instock amount
                 if (stock[2] == DBNull.Value) { TempData["numberofgoods" + rowcount.ToString()] = ""; }
                 else
                 { TempData["numberofgoods" + rowcount.ToString()] = stock[2]; }
                }

                OpenStock.Close();
                instockrecord.Clear();
            }

            public async Task Submit_gaming_data(string username) {
              SqlConnection OpenStock = new SqlConnection(SessionKey.connection);
              OpenStock.Open();

              var update_captial = "UPDATE Fianacial set capital = @currentcapital where UserName = @user";
              var update_stock = "UPDATE Stock set GoodsName = @Goods where UserName = @user and ShelfNum= @shelfnumber";
              var update_setprice = "UPDATE Stock set GoodsPrice =@GoodsPrice where UserName= @user and ShelfNum= @shelfnumber";
              var update_setstocknumber = "UPDATE Stock set InStockNumber=@Number where UserName= @user and ShelfNum= @shelfnumber";
            
              SqlCommand latest_capital = new SqlCommand(update_captial, OpenStock);
              latest_capital.Parameters.AddWithValue("@user", username);
              latest_capital.Parameters.AddWithValue("@currentcapital", TempData["CurrentCapital"].ToString());
              await latest_capital.ExecuteNonQueryAsync();
            
              for (int i = 1; i < 19; i++)
              {
                SqlCommand Latest_stockinfo = new SqlCommand(update_stock, OpenStock);
                Latest_stockinfo.Parameters.AddWithValue("@user", username);
                Latest_stockinfo.Parameters.AddWithValue("@Goods", TempData["nameofgoods" + i.ToString()].ToString());
                Latest_stockinfo.Parameters.AddWithValue("@shelfnumber", i);
                Latest_stockinfo.ExecuteNonQuery();
              }
              
              for (int i = 1; i < 19; i++)
              {
                SqlCommand Latest_stockprice = new SqlCommand(update_setprice, OpenStock);
                Latest_stockprice.Parameters.AddWithValue("@user", username);
                Latest_stockprice.Parameters.AddWithValue("@GoodsPrice", TempData["priceofgoods" +i.ToString()].ToString());
                Latest_stockprice.Parameters.AddWithValue("@shelfnumber", i);
                Latest_stockprice.ExecuteNonQuery();
              }
              
              for (int i = 1; i < 19; i++)
              {
                SqlCommand Latest_stocknumber = new SqlCommand(update_setstocknumber, OpenStock);
                Latest_stocknumber.Parameters.AddWithValue("@user", username);
                Latest_stocknumber.Parameters.AddWithValue("@Number",TempData["numberofgoods"+i.ToString()].ToString());
                Latest_stocknumber.Parameters.AddWithValue("@shelfnumber", i);
                Latest_stocknumber.ExecuteNonQuery();
              }
        }
        //gaming view controller tasks end here


        //User Regesitration
        public async Task Shelf_Construction(string username)
            {
                SqlConnection userinfoinject = await Task.FromResult(new SqlConnection(SessionKey.connection));
                userinfoinject.Open();

                for (int x = 1; x < 19; x++)
                {
                    var regeshopprofile = "insert into Stock (Id,UserName,ShelfNum) select Count(*)+1,@regmanager,@shelfnumber from Stock";
                    var haveshopprofile = new SqlCommand(regeshopprofile, userinfoinject);
                    haveshopprofile.Parameters.AddWithValue("@regmanager", username);
                    haveshopprofile.Parameters.AddWithValue("@shelfnumber", x);
                    haveshopprofile.ExecuteNonQuery();
                }
                userinfoinject.Close();
            }

            public async Task Shop_registration(string user, string password, string Repassword)
            {
                SqlConnection userinfoinject = new SqlConnection(SessionKey.connection);
                userinfoinject.Open();

                var userupdatequery = "INSERT INTO userinfo (UserName,password,Repassword) VALUES (@user,@password,@repassword)";
                var updateuserinfo = new SqlCommand(userupdatequery, userinfoinject);
                updateuserinfo.Parameters.AddWithValue("@user", user);
                updateuserinfo.Parameters.AddWithValue("@password", password);
                updateuserinfo.Parameters.AddWithValue("@repassword", Repassword);
                await updateuserinfo.ExecuteNonQueryAsync();

                userinfoinject.Close();
            }

            public async Task Basic_capital(string username)
            {
                SqlConnection userinfoinject = new SqlConnection(SessionKey.connection);
                userinfoinject.Open();

                var givecaptial = "insert into Fianacial (Id,UserName,Capital) select COUNT(*)+1,@yourname,@gaincapital from Fianacial";
                var gaincapital = new SqlCommand(givecaptial, userinfoinject);
                gaincapital.Parameters.AddWithValue("@yourname", username);
                gaincapital.Parameters.AddWithValue("@gaincapital", 5000);
                await gaincapital.ExecuteNonQueryAsync();
            }
            // block end here

     
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        
        public async Task<IActionResult> Login(string username, string password)
        {
            var userinfoquery = "select UserName from userinfo where UserName = @userlogin and password = @loginpass";
            SqlConnection LOGINAUTH = await Task.FromResult(new SqlConnection(SessionKey.connection));

            var getuserdata = await Task.FromResult(username);
            var getpass = await Task.FromResult(password);

            LOGINAUTH.Open();
            SqlCommand getuserinfo = await Task.FromResult(new SqlCommand(userinfoquery, LOGINAUTH));
            await Task.Run(() => getuserinfo.Parameters.AddWithValue("@userlogin", getuserdata.ToString()));
            await Task.Run(() => getuserinfo.Parameters.AddWithValue("@loginpass", getpass.ToString()));

            await getuserinfo.ExecuteNonQueryAsync();
            SqlDataReader whetherlogin = await Task.FromResult(getuserinfo.ExecuteReader());
            if (whetherlogin.HasRows == false)
            {
                ViewBag.Message = "登陆失败";
                
            }
            else
            {
                HttpContext.Session.SetString(SessionKey.user_name,getuserdata);
                return RedirectToAction("Gaming");
            }

            return View();
        }



        [HttpGet]
        public ActionResult Gaming(
            //submit argument is used by .net mvc api to get this type name
            //and this will be the ref to search every html element whose name attribute matches the ref
            //use switch case block, developer can easily set up different code block for 
            //each element.
            string submit)
        {
            ViewData["Shopmaster"] = "今日店长   " + HttpContext.Session.GetString(SessionKey.user_name);
            var supply = Task.Run(async () => await Supplies_method());
            supply.Wait();
            if (supply.IsCompleted == true)
            {  
                var open = Task.Run(async () => await Openrecord(HttpContext.Session.GetString(SessionKey.user_name)));
                open.Wait();
                if (open.IsCompleted == true)
                {
                    var capital = Task.Run(async () => await Getcapital(HttpContext.Session.GetString(SessionKey.user_name)));
                    capital.Wait();
                    if (capital.IsCompleted == true)
                    {
                        open.Dispose();
                        capital.Dispose();
                        
                    }
                }
            }

            //end
            
            if (submit == "openstore")
            {
                TempData["CurrentCapital"] = Request.Query["Capital"].ToString();
                for(int i = 1; i < 19; i++)
                {
                    TempData["nameofgoods" + i.ToString()] = Request.Query["Name" + i.ToString()].ToString();
                    TempData["priceofgoods" + i.ToString()] = Request.Query["price" + i.ToString()].ToString();
                    TempData["numberofgoods" + i.ToString()] = Request.Query["number" + i.ToString()].ToString();
                }
                var update = Task.Run(async () => await Submit_gaming_data(HttpContext.Session.GetString(SessionKey.user_name)));
                update.Wait();
                return RedirectToAction("Gaming");
            }


            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult test()
        {
            for (int i = 0; i < 2; i++)
            {
                TempData["jj"+i.ToString()] = HttpContext.Session.GetString(SessionKey.user_name);
            }
            
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
