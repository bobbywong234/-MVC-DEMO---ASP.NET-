﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    public class BackEndParameters
    {
        public static readonly string[] supplyitem = {"USB线", "包子", "充电宝" , "蛋糕" ,
        "豆奶","饭团", "关东煮","果汁","红烧牛肉面","花生米","鸡仔饼","咖啡","咖喱鱼丸",
        "烤香肠","可乐","绿茶","美味棒","面包","奶茶","奶昔","能量饮料","牛奶","糯米糍",
        "啤酒","巧克力","薯片","酸奶","甜甜圈","威化饼","仙贝","香烟","杏仁","雪糕",
        "雨伞","杂志","纸巾"};

        public static readonly int[] supplybasicprice =
        {
        8, 2, 12, 3, 1, 2, 3, 2, 2, 1, //10
        2, 4, 4, 2, 2, 2, 1, 2, 4, 4, //20
        2, 2, 3, 2, 2, 2, 4, 1, 1, 1, //30
        10, 7, 5, 9, 2, 1
        };

    }
}
