﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    public class SessionKey
    {
        public const string password = "pass";
        public const string Supply_info_session_key = "Supply_info";
        public const string Supply_number_session_key = "Supply_number";
        public const string Wholesale_price_session_key = "Wholesale_price";
        public const string user_name = "Username";
        public const string capital = "Capital";
        public const string goods = "goods";
        public const string number = "number";
        public const string price = "price";
        public const string connection = "Data Source=lost\\sqlexpress;Initial Catalog=ConStore;Integrated Security=True;Pooling=True";
     }
}
