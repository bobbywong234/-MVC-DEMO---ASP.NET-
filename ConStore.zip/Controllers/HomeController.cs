﻿using System;
using System.Collections;
using System.Data;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Threading;


//Before deploy the service 
//install any device that was metion under the link below//https://docs.microsoft.com/en-us/aspnet/web-forms/overview/deployment/visual-studio-web-deployment/deploying-to-iis//go to control panel -> programs-> programs and feature-> turn windows features on and off
//->click the option .net framwork 4.7 advance or above on -> under this option go to WCF Services
//-> click http activation to deploy the service

   // For database connection, we need to go to the web.config and add connectionstrings tag under 
   // the configuration elements, by providing database name, data server name, providers name, etc.
   //example code below:
    //<connectionStrings>
   // <add name = "DefaultConnection"
   //      connectionString="Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False" providerName="System.Data.SqlClient" />
 //  </connectionStrings>

   // using the ssms to creat logins for iis, using IIS APPPOOL / MyAppName (ps the App name is under IIS Panel's Site folder)
   // then map logins to the user of target database

    //    @Styles.Render("~/Content/css")
   // @Scripts.Render("~/bundles/modernizr")

//Caution: if a controller want to access html value, all the named html element should be included in one form with submit element
//or multiple submit element

namespace $safeprojectname$.Controllers
{

    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "您好，这是我所做Web App的范例.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "我的电子邮箱式：495068849@qq.com";
            return View();
        }

        public ActionResult Registerary()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserInfo(string LOGIN, string PASS,string REPASS)
        {
            Session["User"] = LOGIN;
            Session["Password"] = PASS;
            Session["ReEnterPass"] = REPASS;

            SqlConnection userinfoinject=new SqlConnection();


            try
            {
                var connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";

                userinfoinject = new SqlConnection(connectionstring);
                userinfoinject.Open();

                var userupdatequery = "INSERT INTO userinfo (UserName,password,Repassword) VALUES (@user,@password,@repassword)";
                var updateuserinfo = new SqlCommand(userupdatequery, userinfoinject);
                updateuserinfo.Parameters.AddWithValue("@user", Session["User"].ToString());
                updateuserinfo.Parameters.AddWithValue("@password", Session["Password"].ToString());
                updateuserinfo.Parameters.AddWithValue("@repassword", Session["ReEnterPass"].ToString());
                updateuserinfo.ExecuteNonQuery();

                var givecaptial = "insert into Fianacial (Id,UserName,Capital) select COUNT(*)+1,@yourname,@gaincapital from Fianacial";
                var gaincapital = new SqlCommand(givecaptial, userinfoinject);
                gaincapital.Parameters.AddWithValue("@yourname", Session["User"].ToString());
                gaincapital.Parameters.AddWithValue("@gaincapital", 5000);
                gaincapital.ExecuteNonQuery();

                for (int x = 1; x < 19; x++)
                {
                    var regeshopprofile = "insert into Stock (Id,UserName,ShelfNum) select Count(*)+1,@regmanager,@shelfnumber from Stock";
                    var haveshopprofile = new SqlCommand(regeshopprofile, userinfoinject);
                    haveshopprofile.Parameters.AddWithValue("@regmanager", Session["User"].ToString());
                    haveshopprofile.Parameters.AddWithValue("@shelfnumber", x);
                    haveshopprofile.ExecuteNonQuery();
                }
                
            }
            catch
            {
                return RedirectToAction("RegFail");
            }


            return View();
        }

        [HttpGet]
        public ActionResult Login(string username, string password)
        {

            Session["TypedPassword"] = password;
            Session["NameofUser"] = username;
            
            string connectionstring;
            var userinfoquery = "select UserName from userinfo where UserName = @userlogin and password = @loginpass";
            connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection LOGINAUTH = new SqlConnection(connectionstring);
            LOGINAUTH.Open();
            
            SqlCommand getuserinfo = new SqlCommand(userinfoquery,LOGINAUTH);
            getuserinfo.Parameters.AddWithValue("@userlogin", Session["NameofUser"].ToString());
            getuserinfo.Parameters.AddWithValue("@loginpass", Session["TypedPassword"].ToString());
            getuserinfo.ExecuteNonQuery();
            SqlDataReader whetherlogin = getuserinfo.ExecuteReader();
            if (whetherlogin.HasRows == false)
            {
                ViewBag.Message = "登录失败";
            }
            else
            {
                return RedirectToAction("Gaming");
            }

            return View();
        }

        [HttpGet]
        public ActionResult Gaming(string submit, 
            string price1,string price2, string price3,string price4,string price5, string price6, string price7,  string price8,string price9,
            string price10, string price11,string price12, string price13,string price14, string price15,string price16, string price17,
            string price18,
            string Name1,string Name2, string Name3, string Name4, string Name5, string Name6, string Name7,
            string Name8, string Name9, string Name10, string Name11, string Name12, string Name13, 
            string Name14,string Name15, string Name16, string Name17, string Name18,
            string number1, int? number2, int? number3, int? number4, int? number5, int? number6, int? number7, 
            int? number8, int? number9, int? number10,int? number11, int? number12, int? number13, int? number14,
            int? number15, int? number16, int? number17, int? number18,
            string need1, string need2, string need3, string need4, string need5, string need6, string need7,string need8,
            string need9, int? Revenue, int? Capital)
        {
            ViewBag.Message ="今日店长   " + Session["NameofUser"].ToString();
            string connectionstring;
            connectionstring = @"Data Source=.\SQLExpress;Initial Catalog=$safeprojectname$;Integrated Security=True;Pooling=False";
            SqlConnection OpenStock = new SqlConnection(connectionstring);
            OpenStock.Open();

            //collect instock information based on last login
            var stockinformquery = "select GoodsName,GoodsPrice,InStockNumber from Stock where UserName = @userlogin";
            SqlCommand getstockinfo = new SqlCommand(stockinformquery, OpenStock);
            getstockinfo.Parameters.AddWithValue("@userlogin", Session["NameofUser"].ToString());
            getstockinfo.ExecuteNonQuery();
            SqlDataAdapter stockinfo = new SqlDataAdapter(getstockinfo);
            DataTable instockrecord = new DataTable();
            stockinfo.Fill(instockrecord);

            int rowcount = new int();
            foreach (DataRow stock in instockrecord.Rows)
            {
                rowcount += 1;
                //instock Record
                Session["nameofgoods" + rowcount.ToString()] = stock[0].ToString();

                //Selling Price
                if (stock[1] == DBNull.Value) { Session["priceofgoods" + rowcount.ToString()] = ""; }
                //else
                { Session["priceofgoods" + rowcount.ToString()] = stock[1]; }

                //Instock amount
                if (stock[2] == DBNull.Value) { Session["numberofgoods" + rowcount.ToString()] = ""; }
                else
                { Session["numberofgoods" + rowcount.ToString()] = stock[2]; }
            }

            instockrecord.Clear();

            //end

            switch (submit)
            {
                case "确认零售价":
                    Random needrand = new Random();
                    
                    Session["priceofgoods1"] = price1;
                    Session["priceofgoods2"] = price2;
                    Session["priceofgoods3"] = price3;
                    Session["priceofgoods4"] = price4;
                    Session["priceofgoods5"] = price5;
                    Session["priceofgoods6"] = price6;
                    Session["priceofgoods7"] = price7;
                    Session["priceofgoods8"] = price8;
                    Session["priceofgoods9"] = price9;
                    Session["priceofgoods10"] = price10;
                    Session["priceofgoods11"] = price11;
                    Session["priceofgoods12"] = price12;
                    Session["priceofgoods13"] = price13;
                    Session["priceofgoods14"] = price14;
                    Session["priceofgoods15"] = price15;
                    Session["priceofgoods16"] = price16;
                    Session["priceofgoods17"] = price17;
                    Session["priceofgoods18"] = price18;

                    for (int i = 1; i < 19; i++)
                    {
                        var stockpriceupdate = "update Stock set GoodsPrice = @latestprice where UserName = @Master and GoodsName = @Catagory";
                        SqlCommand priceupdate = new SqlCommand(stockpriceupdate, OpenStock);
                        
                        priceupdate.Parameters.AddWithValue("@Master", Session["NameofUser"]);
                        if (Session["nameofgoods" + i.ToString()] == null && Session["priceofgoods" + i.ToString()] == null)
                        {
                            priceupdate.Parameters.AddWithValue("@Catagory", DBNull.Value);
                            priceupdate.Parameters.AddWithValue("@latestprice", DBNull.Value);
                        }
                        else
                        {
                            priceupdate.Parameters.AddWithValue("@Catagory", Session["nameofgoods" + i.ToString()]);
                            priceupdate.Parameters.AddWithValue("@latestprice", Session["priceofgoods" + i.ToString()]);
                        }
                        priceupdate.ExecuteNonQuery();
                    }
                    break;


                case "buy":
                    Session["nameofgoods1"] = Name1;
                    Session["nameofgoods2"] = Name2;
                    Session["nameofgoods3"] = Name3;
                    Session["nameofgoods4"] = Name4;
                    Session["nameofgoods5"] = Name5;
                    Session["nameofgoods6"] = Name6;
                    Session["nameofgoods7"] = Name7;
                    Session["nameofgoods8"] = Name8;
                    Session["nameofgoods9"] = Name9;
                    Session["nameofgoods10"] = Name10;
                    Session["nameofgoods11"] = Name11;
                    Session["nameofgoods12"] = Name12;
                    Session["nameofgoods13"] = Name13;
                    Session["nameofgoods14"] = Name14;
                    Session["nameofgoods15"] = Name15;
                    Session["nameofgoods16"] = Name16;
                    Session["nameofgoods17"] = Name17;
                    Session["nameofgoods18"] = Name18;
                    Session["numberofgoods1"] = number1;
                    Session["numberofgoods2"] = number2;
                    Session["numberofgoods3"] = number3;
                    Session["numberofgoods4"] = number4;
                    Session["numberofgoods5"] = number5;
                    Session["numberofgoods6"] = number6;
                    Session["numberofgoods7"] = number7;
                    Session["numberofgoods8"] = number8;
                    Session["numberofgoods9"] = number9;
                    Session["numberofgoods10"] = number10;
                    Session["numberofgoods11"] = number11;
                    Session["numberofgoods12"] = number12;
                    Session["numberofgoods13"] = number13;
                    Session["numberofgoods14"] = number14;
                    Session["numberofgoods15"] = number15;
                    Session["numberofgoods16"] = number16;
                    Session["numberofgoods17"] = number17;
                    Session["numberofgoods18"] = number18;
                    Session["CurrentCapital"] = Capital;

                    //update stock
                    for (int i = 1; i < 19; i++)
                    {
                      var shelfupdate = "update Stock set GoodsName = @latestname, InStockNumber = @latestnum where UserName = @Master and ShelfNum = @Snum";
                    SqlCommand priceupdate = new SqlCommand(shelfupdate, OpenStock);
                    priceupdate.Parameters.AddWithValue("@Master", Session["NameofUser"]);
                    if (Convert.ToString(Session["nameofgoods" + i.ToString()]) == "" && Convert.ToString(Session["numberofgoods" + i.ToString()]) == "")
                    {
                       priceupdate.Parameters.AddWithValue("@latestname", DBNull.Value);
                      priceupdate.Parameters.AddWithValue("@latestnum", DBNull.Value);
                    }
                    else
                    {
                      priceupdate.Parameters.AddWithValue("@latestname", Session["nameofgoods" + i.ToString()]);
                     priceupdate.Parameters.AddWithValue("@latestnum",Session["numberofgoods" + i.ToString()]);
                    }
                    priceupdate.Parameters.AddWithValue("@Snum", i);
                    priceupdate.ExecuteNonQuery();
                    }
                    //end

                    //update capital
                    var updatecapital = "update Fianacial set Capital=@newcapital where UserName = @ShopMaster";
                    SqlCommand capitaldata = new SqlCommand(updatecapital, OpenStock);
                    capitaldata.Parameters.AddWithValue("@newcapital", Convert.ToInt32(Session["CurrentCapital"]));
                    capitaldata.Parameters.AddWithValue("@ShopMaster", Session["NameofUser"]);
                    capitaldata.ExecuteNonQuery();
                    //end

                    //query new capital
                    DataTable capitaltable = new DataTable();
                    var newcapital = "select Capital from Fianacial where UserName =@StoreMaster";
                    SqlCommand newcapitaldata = new SqlCommand(newcapital, OpenStock);
                    newcapitaldata.Parameters.AddWithValue("@StoreMaster", Session["NameofUser"]);
                    newcapitaldata.ExecuteNonQuery();
                    SqlDataAdapter capitalreader = new SqlDataAdapter(newcapitaldata);
                    capitalreader.Fill(capitaltable);
                    foreach(DataRow capitalrow in capitaltable.Rows)
                    {
                        Session["CurrentCapital"] = capitalrow[0];
                    }
                    //end
                    break;

                case "openstore":

                    //query supply data
                    DataTable marketdata = new DataTable();
                    Random rand = new Random();
                    Session["randomstartnumber"] = rand.Next(1, 12);
                    Random supplyfactor = new Random();
                    Random pricefactor = new Random();

                    for (int i = 0; i < 24; i++)
                    {
                        Session["randomizsupply" + i.ToString()] = supplyfactor.Next(10, 99);
                        Session["randomizprice" + i.ToString()] = pricefactor.Next(4, 11);
                        var marketingupdateamount = "update Market set ProductNumber=@randsupply where id = @rowid";
                        var marketingupdateprice = "update Market set ProductionPrice=@randomizprice where id = @rowid";
                        SqlCommand marketingamount = new SqlCommand(marketingupdateamount, OpenStock);
                        SqlCommand marketingprice = new SqlCommand(marketingupdateprice, OpenStock);
                        marketingamount.Parameters.AddWithValue("@randsupply", Convert.ToInt32(Session["randomizsupply" + i.ToString()]));
                        marketingprice.Parameters.AddWithValue("@randomizprice", Convert.ToInt32(Session["randomizprice" + i.ToString()]));
                        marketingamount.Parameters.AddWithValue("@rowid", Convert.ToInt32(Session["randomstartnumber"]) + i);
                        marketingprice.Parameters.AddWithValue("@rowid", Convert.ToInt32(Session["randomstartnumber"]) + i);
                        marketingamount.ExecuteNonQuery();
                        marketingprice.ExecuteNonQuery();
                    }

                    var marketinfoquery = "select ProductName,ProductNumber,ProductionPrice from Market where id between @rowstartid and @rowendid";
                    SqlCommand getmarketinfo = new SqlCommand(marketinfoquery, OpenStock);
                    getmarketinfo.Parameters.AddWithValue("@rowstartid", Convert.ToInt32(Session["randomstartnumber"]));
                    getmarketinfo.Parameters.AddWithValue("@rowendid", Convert.ToInt32(Session["randomstartnumber"]) + 24);

                    getmarketinfo.ExecuteNonQuery();


                    SqlDataAdapter markettrend = new SqlDataAdapter(getmarketinfo);
                    markettrend.Fill(marketdata);

                    int Supplycount = new int();
                    foreach (DataRow ProductMarket in marketdata.Rows)
                    {
                        Supplycount += 1;
                        Session["nameofproduct" + Supplycount.ToString()] = ProductMarket[0].ToString();
                        Session["numberofproduct" + Supplycount.ToString()] = (int)ProductMarket[1];
                        Session["ProductionPrice" + Supplycount.ToString()] = (int)ProductMarket[2];
                    }

                    marketdata.Clear();
                    //end

                    Random shelfrand = new Random();
                    Session["StartRandom"] = shelfrand.Next(1, 27);
                    for (int r = Convert.ToInt32(Session["StartRandom"]); r < Convert.ToInt32(Session["StartRandom"]) + 3; r++)
                    {
                        Session["needs" + (r - Convert.ToInt32(Session["StartRandom"]) + 1).ToString()] =
                            $safeprojectname$.Models.Supply.supplyitem[r - 1].ToString();
                    }

                    Session["StartRandom"] = shelfrand.Next(1, 27);
                    for (int r = Convert.ToInt32(Session["StartRandom"]) + 3; r < Convert.ToInt32(Session["StartRandom"]) + 6; r++)
                    {
                        Session["needs" + (r - Convert.ToInt32(Session["StartRandom"]) + 1).ToString()] =
                            $safeprojectname$.Models.Supply.supplyitem[r - 4].ToString();
                    }

                    Session["StartRandom"] = shelfrand.Next(1, 27);
                    for (int r = Convert.ToInt32(Session["StartRandom"]) + 6; r < Convert.ToInt32(Session["StartRandom"]) + 9; r++)
                    {
                        Session["needs" + (r - Convert.ToInt32(Session["StartRandom"]) + 1).ToString()] =
                            $safeprojectname$.Models.Supply.supplyitem[r - 7].ToString();
                    }

                    need1 = Convert.ToString(Session["needs1"]);
                    need2 = Convert.ToString(Session["needs2"]);
                    need3 = Convert.ToString(Session["needs3"]);
                    need4 = Convert.ToString(Session["needs4"]);
                    need5 = Convert.ToString(Session["needs5"]);
                    need6 = Convert.ToString(Session["needs6"]);
                    need7 = Convert.ToString(Session["needs7"]);
                    need8 = Convert.ToString(Session["needs8"]);
                    need9 = Convert.ToString(Session["needs9"]);

                    //update financial data

                    //get capital data first
                    DataTable informationtable = new DataTable();
                    var capitalquery = "select Capital from Fianacial where UserName =@LoginManager";
                    SqlCommand basicinfo = new SqlCommand(capitalquery, OpenStock);
                    basicinfo.Parameters.AddWithValue("@LoginManager", Session["NameofUser"].ToString());

                    basicinfo.ExecuteNonQuery();
                    SqlDataAdapter getinfofirst = new SqlDataAdapter(basicinfo);
                    getinfofirst.Fill(informationtable);
                    foreach (DataRow informationdata in informationtable.Rows)
                    {
                        Session["CurrentCapital"] = informationdata[0].ToString();
                    }
                    

                    //update capital data
                    var financialupdate = "update Fianacial set Capital =@newvalue where UserName =@Currentlogin";
                    SqlCommand financialdata = new SqlCommand(financialupdate,OpenStock);
                    financialdata.Parameters.AddWithValue("@newvalue", Convert.ToInt32(Session["CurrentCapital"])+Revenue);
                    financialdata.Parameters.AddWithValue("@Currentlogin", Session["NameofUser"]);
                    financialdata.ExecuteNonQuery();

                    //second query for capital
                    informationtable.Clear();
                    basicinfo.ExecuteNonQuery();
                    SqlDataAdapter getinfosecond = new SqlDataAdapter(basicinfo);
                    getinfofirst.Fill(informationtable);
                    foreach (DataRow informationdata in informationtable.Rows)
                    {
                        Session["CurrentCapital"] = informationdata[0].ToString();
                    }
                    informationtable.Clear();

                    //end
                    break;
            }
           
          
            return View("Gaming","BlankLayerOut");
        }

        public ActionResult RegFail()
        {
            return View();
        }

    }
}