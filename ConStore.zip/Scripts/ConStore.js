﻿//use parseint javascript can parse any integer in one var and combine all int together

function pressbutton(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.backgroundSize = "95% 95%";
}

function backtodefaultstyle(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.backgroundSize = "100% 100%";

}

function bluegrowingtext(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.textShadow = "1px 1px 2px blue, 0 0 0.3em blue";
}

function bluetext(elementid) {
    var gamingobject = document.getElementById(elementid);
    gamingobject.style.textShadow = "1px 1px 2px blue";
}

function reloadpage() {
    window.location.reload(true);
}

function increasvalues(elementid, titleid) {
    if (document.getElementById(titleid).innerHTML == "") { }
    else
    {
        var value = parseInt(document.getElementById(elementid).value, 10);
        value = isNaN(value) ? 0 : value;
        value++;
        document.getElementById(elementid).value = value;   
    }
}

function decreasvalues(elementid, titleid) {
    if (document.getElementById(titleid).innerHTML == "") { }
    else
    {
        var value = parseInt(document.getElementById(elementid).value, 10);
        value = isNaN(value) ? 0 : value;
        value--;
        document.getElementById(elementid).value = value;
    }
}

function buttoneffect() {
    document.body.style.fontSize = '20px';
}

function buyin(buyingoods,instock,instocknumber) {
    var i;
    var t;
    var instockcat = document.getElementById(instock);
    var product = document.getElementById(buyingoods);
    var numberofinstock = document.getElementById(instocknumber);

    for (i = 1; i < 18; i++) {
        if (document.getElementById("goodsname" + i.toString()).value == product.innerText) {
            
            for (t = 1; t < 25; t++) {
                if (document.getElementById("product" + t.toString()).innerText == product.innerText) {
                    var value = parseInt(document.getElementById("supply" + t.toString()).innerHTML,10) + parseInt(document.getElementById("num" + i.toString()).value, 10);
                    document.getElementById("supply" + t.toString()).innerHTML = value;
                }
               
            }

                document.getElementById("goodsname" + i.toString()).value = "";
                document.getElementById("num" + i.toString()).value = "";
        }
    }



    if (instockcat.value != "") {
        var replacestock = confirm("确定要替换货品？");
        if (replacestock) {
            instockcat.value = product.innerText;
        }
        else {
            
        }
    }
    else {
        instockcat.value = product.innerText;
        numberofinstock.value = 0;
    }
}

function stockin(instocknum, instockproduct) {
    var stockproduct = document.getElementById(instockproduct);
    var stocknum = document.getElementById(instocknum);
    var i;
    for (i = 1; i < 25; i++) {
        var supplyproduct = document.getElementById("product" + i.toString());
        var supplynum = document.getElementById("supply" + i.toString());
        if (stockproduct.value == supplyproduct.innerText) {
            var value = parseInt(stocknum.value, 10);
            value++;
            stocknum.value = value;
            supplynum.innerHTML -= 1;

            var dedcutedamount = parseInt(document.getElementById("Capital").value,10) -
                parseInt(document.getElementById("productprice" + i.toString()).innerHTML, 10)
            dedcutedamount = isNaN(dedcutedamount) ? 0 : dedcutedamount;
            document.getElementById("Capital").value = dedcutedamount;
            
        }

    }

}

function canclebuy(instocknum, instockproduct) {
    var stockproduct = document.getElementById(instockproduct);
    var stocknum = document.getElementById(instocknum);
    var i;
    for (i = 1; i < 25; i++) {
        var supplyproduct = document.getElementById("product" + i.toString());
        var supplynum = document.getElementById("supply" + i.toString());
        if (stockproduct.value == supplyproduct.innerText) {
            var value = parseInt(stocknum.value, 10);
            var value2 = parseInt(supplynum.innerText, 10);
            value--;
            value2++;
            stocknum.value = value;
            supplynum.innerHTML = value2;

            var withdrawtrade = parseInt(document.getElementById("Capital").value, 10) +
                parseInt(document.getElementById("productprice" + i.toString()).innerHTML, 10)
            withdrawtrade = isNaN(withdrawtrade) ? 0 : withdrawtrade;
            document.getElementById("Capital").value = withdrawtrade;
        }
    }
}

function clearupshelf(productid) {
    var q;
    var productname = document.getElementById(productid);

    for (q = 1; q < 19; q++) {
        if (document.getElementById("goodsname" + q.toString()).value == productname.innerText) {
            document.getElementById("goodsname" + q.toString()).value = "";
            document.getElementById("num" + q.toString()).value = "";
        }
    }
}

function getsold(Solditem) {
    var item = document.getElementById(Solditem).value;
    var capital = document.getElementById('Revenue');
    var rand = Math.floor((Math.random() * 5) + 1);

        for (var x = 1; x < 19; x++) {
            if (document.getElementById("goodsname" + x.toString()).value == item)
            {
                if (confirm("确定要卖出" + item + ",卖出数量" + rand)) {
                    if (document.getElementById("num" + x.toString()).value < rand) {
                        document.getElementById("goodsname" + x.toString()).value = "";
                        document.getElementById("num" + x.toString()).value = "";
                        var revenue = parseInt(capital.value, 10) + rand * parseInt(document.getElementById("price" + x.toString()).value,10)
                        capital.value = parseInt(revenue, 10);
                        break;
                    }

                    if (document.getElementById("num" + x.toString()).value >= rand)
                    {
                        var revenue = parseInt(capital.value, 10) + rand * parseInt(document.getElementById("price" + x.toString()).value,10)
                        capital.value = parseInt(revenue,10);
                        var newstocknum = parseInt(document.getElementById("num" + x.toString()).value, 10) - rand
                        document.getElementById("num" + x.toString()).value = newstocknum;
                        document.getElementById(Solditem).value = "";
                        break;
                    }
                    
                }
            }
        }

}
