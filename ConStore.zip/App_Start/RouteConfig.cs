﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace $safeprojectname$
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //action param is the bundle of action method in its controller, 
            //so by typing /gaming behind the hostname or dns name will redirect
            //you to the index , you can also add actionresult method in controller
            //to redirect different view under Gaming folder
            //So in here the param behind name: is the views folder
            //first part of url doesn't have to be the same with name of view folder

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
